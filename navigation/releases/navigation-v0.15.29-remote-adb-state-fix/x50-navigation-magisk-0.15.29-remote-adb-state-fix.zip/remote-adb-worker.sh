#!/system/bin/sh
# Fail-closed remote ADB worker owned by the X50 Navigation Magisk module.
# It never evaluates server-supplied shell text and never touches ADB until a
# complete, explicit session is present. The Navigation app owns the outbound
# TLS WebSocket tunnel; this worker owns only the temporary local adbd setup.

MODDIR="$1"
STATE_DIR=/data/adb/x50-navigation-remote-adb
KEY_FILE="$STATE_DIR/adb-public-key"
ADDED_KEY_FILE="$STATE_DIR/added-adb-key"
OWNED_FILE="$STATE_DIR/owned"
IDLE_CLEANUP_FILE="$STATE_DIR/idle-cleanup-complete"
PID_FILE="$STATE_DIR/tunnel.pid"
PREVIOUS_PORT="$STATE_DIR/previous-service-adb-port"
PREVIOUS_PERSIST_PORT="$STATE_DIR/previous-persist-adb-port"
PREVIOUS_GLOBAL_PORT="$STATE_DIR/previous-global-adb-port"
CHAIN=X50NAV_REMOTE_ADB

get() { settings get global "$1" 2>/dev/null; }
state() { settings put global x50_navigation_remote_adb_worker_state "$1" >/dev/null 2>&1 || true; }
digits() { case "$1" in ''|*[!0-9]*) return 1 ;; *) return 0 ;; esac; }

remove_firewall() {
  command -v iptables >/dev/null 2>&1 || return
  while iptables -D INPUT -p tcp --dport 5555 -j "$CHAIN" >/dev/null 2>&1; do :; done
  iptables -F "$CHAIN" >/dev/null 2>&1 || true
  iptables -X "$CHAIN" >/dev/null 2>&1 || true
}

remove_key() {
  adb_keys=/data/misc/adb/adb_keys
  [ -s "$KEY_FILE" ] && [ -f "$adb_keys" ] || return
  grep -F -x -v -f "$KEY_FILE" "$adb_keys" > "$adb_keys.x50-navigation.tmp" 2>/dev/null || true
  [ -f "$adb_keys.x50-navigation.tmp" ] || return
  chmod 0600 "$adb_keys.x50-navigation.tmp" >/dev/null 2>&1 || true
  mv "$adb_keys.x50-navigation.tmp" "$adb_keys"
}

cleanup() {
  if [ -f "$PID_FILE" ]; then
    pid="$(cat "$PID_FILE" 2>/dev/null | tr -cd '0-9')"
    [ -n "$pid" ] && kill "$pid" >/dev/null 2>&1 || true
  fi
  remove_firewall
  [ -f "$ADDED_KEY_FILE" ] && remove_key
  # Restore only an adbd state that this worker previously recorded.  It does
  # not disable a separately configured wireless ADB service.
  if [ -f "$OWNED_FILE" ]; then
    previous="$(cat "$PREVIOUS_PORT" 2>/dev/null)"
    previous_persist="$(cat "$PREVIOUS_PERSIST_PORT" 2>/dev/null)"
    previous_global="$(cat "$PREVIOUS_GLOBAL_PORT" 2>/dev/null)"
    # A module update can inherit state created by the older worker, which
    # recorded only PREVIOUS_PORT.  Its missing value means "use the existing
    # persisted TCP ADB setting", not "turn wireless ADB off".
    if [ ! -f "$PREVIOUS_PERSIST_PORT" ] && [ -z "$previous" ]; then
      previous="$(getprop persist.adb.tcp.port 2>/dev/null)"
    fi
    [ -f "$PREVIOUS_PERSIST_PORT" ] && setprop persist.adb.tcp.port "$previous_persist" >/dev/null 2>&1 || true
    setprop service.adb.tcp.port "$previous" >/dev/null 2>&1 || true
    if [ ! -f "$PREVIOUS_GLOBAL_PORT" ]; then
      :
    elif [ "$previous_global" = "__absent__" ]; then
      settings delete global adb_port >/dev/null 2>&1 || true
    else
      settings put global adb_port "$previous_global" >/dev/null 2>&1 || true
    fi
    stop adbd >/dev/null 2>&1 || true
    start adbd >/dev/null 2>&1 || true
  fi
  rm -f "$KEY_FILE" "$ADDED_KEY_FILE" "$PID_FILE" "$PREVIOUS_PORT" \
    "$PREVIOUS_PERSIST_PORT" "$PREVIOUS_GLOBAL_PORT" "$OWNED_FILE"
}

start() {
  enabled="$(get x50_navigation_remote_adb_enabled)"
  session="$(get x50_navigation_remote_adb_session_id)"
  expires="$(get x50_navigation_remote_adb_expires_at_ms)"
  port="$(get x50_navigation_remote_adb_remote_port)"
  public_key="$(get x50_navigation_remote_adb_public_key)"
  now="$(date +%s 2>/dev/null | tr -cd '0-9')000"

  if [ "$enabled" != 1 ] || ! digits "$expires" || ! digits "$port" \
      || [ "$expires" -le "$now" ] || [ "$port" -lt 23000 ] || [ "$port" -gt 23100 ] \
      || [ -z "$session" ] || [ "${#public_key}" -lt 32 ] || [ "${#public_key}" -gt 8192 ]; then
    # An expired/incomplete session must restore adbd once, not issue stop
    # commands every worker iteration. This is especially important on older
    # Android builds where init leaves adbd disabled after a repeated stop.
    if [ ! -f "$IDLE_CLEANUP_FILE" ]; then
      cleanup
      mkdir -p "$STATE_DIR" >/dev/null 2>&1 || true
      : > "$IDLE_CLEANUP_FILE" 2>/dev/null || true
    fi
    state off; return
  fi
  rm -f "$IDLE_CLEANUP_FILE"
  if [ -f "$OWNED_FILE" ] && [ "$(cat "$OWNED_FILE" 2>/dev/null)" = "$session" ]; then
    state prepared
    return
  fi

  cleanup
  mkdir -p "$STATE_DIR" || { state state_error; return; }
  adb_keys=/data/misc/adb/adb_keys
  # Older Android builds do not create adb_keys until the first manual USB
  # authorisation.  Creating the standard empty file is safe; this worker then
  # appends only the temporary, owner-approved key and removes only that key.
  if [ ! -e "$adb_keys" ]; then
    mkdir -p /data/misc/adb >/dev/null 2>&1 || { state adb_keys_missing; return; }
    : > "$adb_keys" || { state adb_keys_missing; return; }
    chmod 0640 "$adb_keys" >/dev/null 2>&1 || true
  fi
  [ -f "$adb_keys" ] || { state adb_keys_missing; return; }
  command -v iptables >/dev/null 2>&1 || { state firewall_missing; return; }
  printf '%s\n' "$public_key" > "$KEY_FILE" || { state state_error; return; }
  chmod 0600 "$KEY_FILE" >/dev/null 2>&1 || true
  if ! grep -F -x -q -f "$KEY_FILE" "$adb_keys" 2>/dev/null; then
    cat "$KEY_FILE" >> "$adb_keys" || { cleanup; state adb_key_error; return; }
    : > "$ADDED_KEY_FILE"
  fi

  iptables -N "$CHAIN" >/dev/null 2>&1 || true
  iptables -F "$CHAIN" >/dev/null 2>&1 || { cleanup; state firewall_error; return; }
  iptables -A "$CHAIN" -i lo -p tcp --dport 5555 -j ACCEPT >/dev/null 2>&1 || { cleanup; state firewall_error; return; }
  iptables -A "$CHAIN" -p tcp --dport 5555 -j DROP >/dev/null 2>&1 || { cleanup; state firewall_error; return; }
  iptables -I INPUT -p tcp --dport 5555 -j "$CHAIN" >/dev/null 2>&1 || { cleanup; state firewall_error; return; }

  getprop service.adb.tcp.port > "$PREVIOUS_PORT" 2>/dev/null || true
  getprop persist.adb.tcp.port > "$PREVIOUS_PERSIST_PORT" 2>/dev/null || true
  previous_global="$(settings get global adb_port 2>/dev/null)"
  [ "$previous_global" = "null" ] && previous_global=__absent__
  printf '%s\n' "$previous_global" > "$PREVIOUS_GLOBAL_PORT"
  setprop service.adb.tcp.port 5555 >/dev/null 2>&1 || { cleanup; state adbd_error; return; }
  stop adbd >/dev/null 2>&1 || true
  start adbd >/dev/null 2>&1 || { cleanup; state adbd_error; return; }
  printf '%s\n' "$session" > "$OWNED_FILE"
  state prepared
}

# Every boot revokes the capability. Existing owner-managed ADB is untouched
# unless a previous session recorded ownership in this state directory.
cleanup
settings put global x50_navigation_remote_adb_enabled 0 >/dev/null 2>&1 || true
mkdir -p "$STATE_DIR" >/dev/null 2>&1 || true
: > "$IDLE_CLEANUP_FILE" 2>/dev/null || true
state off
while true; do
  start
  sleep 2
done
