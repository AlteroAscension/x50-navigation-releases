#!/system/bin/sh

# A Magisk system-app removal does not always invoke Android's normal APK
# uninstall lifecycle. Clear the exact package sandbox so a permanent offline
# licence, pending activation request and installation ID cannot survive a
# complete Navigation-module removal.
am force-stop ru.lesnik.x50navigation >/dev/null 2>&1 || true
pm clear ru.lesnik.x50navigation >/dev/null 2>&1 || true
rm -rf /data/user/0/ru.lesnik.x50navigation \
  /data/user_de/0/ru.lesnik.x50navigation \
  /data/misc_ce/0/ru.lesnik.x50navigation >/dev/null 2>&1 || true

# Remove only legacy activation mirrors. Ordinary Navigation settings are left
# intact unless their owning app sandbox was removed above.
for key in \
  x50_navigation_enabled \
  x50_navigation_heartbeat_ms \
  x50_navigation_license_json \
  x50_navigation_license_valid \
  x50_navigation_license_status \
  x50_navigation_license_checked_at_ms \
  x50_navigation_installation_id \
  x50_navigation_local_activation_code \
  x50_navigation_local_activation_expires_ms \
  x50_navigation_vin_candidate_hash \
  x50_navigation_vin_stable_reads \
  x50_navigation_test_vin_device \
  x50_navigation_test_vin_property; do
  settings delete global "$key" >/dev/null 2>&1 || true
done
