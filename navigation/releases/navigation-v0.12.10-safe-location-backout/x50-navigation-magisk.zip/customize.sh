#!/system/bin/sh
ui_print "- Installing X50 Navigation"
ui_print "- Enable the module for Yandex Navigator in LSPosed after reboot"
chmod 0755 "$MODPATH/service.sh"
true
