#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done

MODDIR=${0%/*}
DST_DIR=/sdcard/Android/data/ru.lesnik.x50navigation/files
STATUS=$DST_DIR/x50_staging_status.json
LOG=$MODDIR/staging.log

pm grant ru.lesnik.x50navigation android.permission.ACCESS_FINE_LOCATION \
  >/dev/null 2>&1 || true
appops set ru.lesnik.x50navigation android:mock_location allow >/dev/null 2>&1 \
  || appops set ru.lesnik.x50navigation MOCK_LOCATION allow >/dev/null 2>&1 \
  || true

# Never persist the dangerous diagnostic correction bypass across a reboot.
settings put global x50_navigation_gps_correction_disabled 0 >/dev/null 2>&1 \
  || true

# MapKit is the only route source. Remove obsolete staged fallbacks left by
# older module versions so neither diagnostics nor external tools can mistake
# them for current data.
rm -f "$DST_DIR/yandex_guidance_navigation_state" \
  "$DST_DIR/yandex_guidance_navigation_state.state" \
  "$DST_DIR/yandex_guidance_navigation_state.mtime" \
  "$DST_DIR/yandex_known_route_history" \
  "$DST_DIR/yandex_known_route_history.state" \
  "$DST_DIR/yandex_known_route_history.mtime" \
  "$DST_DIR/yandex_exact_route.json" \
  "$DST_DIR/yandex_exact_route.json.state" \
  "$DST_DIR/yandex_exact_route.json.mtime"

stage_file() {
  src="$1"
  name="$2"
  dst="$DST_DIR/$name"
  STAGE_OK=0
  STAGE_MTIME=0
  STAGE_SIZE=0
  [ -s "$src" ] || return
  STAGE_MTIME="$(toybox stat -c %Y "$src" 2>/dev/null || stat -c %Y "$src" 2>/dev/null)"
  STAGE_SIZE="$(toybox stat -c %s "$src" 2>/dev/null || stat -c %s "$src" 2>/dev/null)"
  state="$STAGE_MTIME $STAGE_SIZE"
  previous="$(cat "$dst.state" 2>/dev/null)"
  if [ -s "$dst" ] && [ "$state" = "$previous" ]; then
    STAGE_OK=1
    return
  fi
  mkdir -p "$DST_DIR" >/dev/null 2>&1
  if (toybox cp "$src" "$dst.tmp" 2>/dev/null || cp "$src" "$dst.tmp" 2>/dev/null) \
      && [ -s "$dst.tmp" ]; then
    chmod 0644 "$dst.tmp" >/dev/null 2>&1
    mv "$dst.tmp" "$dst"
    printf '%s\n' "$state" > "$dst.state"
    STAGE_OK=1
    printf '%s staged %s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$name" "$state" >> "$LOG"
  fi
}

(
  while true; do
    stage_file /data/data/ru.yandex.yandexnavi/files/x50_navigation_route.json \
      yandex_navigation_route.json
    mapkit_ok=$STAGE_OK; mapkit_mtime=$STAGE_MTIME; mapkit_size=$STAGE_SIZE
    heartbeat_ms="$(date +%s 2>/dev/null)000"
    mkdir -p "$DST_DIR" >/dev/null 2>&1
    printf '{"heartbeat_ms":%s,"source":"mapkit","mapkit":{"ok":%s,"source_mtime_s":%s,"size":%s}}\n' \
      "$heartbeat_ms" "$mapkit_ok" "$mapkit_mtime" "$mapkit_size" > "$STATUS.tmp" \
      && chmod 0644 "$STATUS.tmp" && mv "$STATUS.tmp" "$STATUS"
    sleep 1
  done
) &

am start-foreground-service -a ru.lesnik.x50navigation.START \
  -n ru.lesnik.x50navigation/.NavigationService >/dev/null 2>&1 \
  || am startservice -a ru.lesnik.x50navigation.START \
  -n ru.lesnik.x50navigation/.NavigationService >/dev/null 2>&1
